import { useState, useMemo } from "react";
import { 
  Compass, 
  Cpu, 
  FolderGit2, 
  Database, 
  Terminal, 
  BookOpen, 
  ArrowUpRight, 
  Sparkles, 
  Check, 
  UserSquare, 
  Activity, 
  Settings,
  Github,
  Coins
} from "lucide-react";
import StackSection from "./components/StackSection";
import FolderStructure from "./components/FolderStructure";
import DatabaseSchema from "./components/DatabaseSchema";
import TraceSimulator from "./components/TraceSimulator";
import CoinSandbox from "./components/CoinSandbox";
import { MISCONCONCEPTION_CATALOG } from "./blueprints";

type TabID = "overview" | "sandbox" | "simulation" | "schema" | "stack" | "directory";

export default function App() {
  const [activeTab, setActiveTab] = useState<TabID>("overview");
  const [selectedEquation, setSelectedEquation] = useState<{ expression: string; a: number; b: number; detectedMisconceptionCode?: string | null } | undefined>(undefined);

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 flex flex-col justify-between selection:bg-indigo-100 selection:text-indigo-900 font-sans">
      
      {/* Top Navigation Bar */}
      <header id="app-header" className="bg-white border-b border-slate-150 sticky top-0 z-50 px-6 py-4">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-indigo-600 text-white rounded-xl shadow-xs">
              <Activity size={22} className="animate-pulse" />
            </div>
            <div>
              <h1 className="font-sans font-bold text-lg md:text-xl text-slate-900 tracking-tight leading-none">
                alamatika <span className="text-indigo-605">core-trace</span>
              </h1>
              <span className="text-2xs font-mono text-slate-400 mt-1 block">FOUNDATIONAL ARCHITECTURE BLUEPRINT</span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-2xs font-mono text-emerald-600 bg-emerald-50 border border-emerald-100 px-2.5 py-1 rounded-full flex items-center gap-1.5 font-medium">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-ping" />
              Senior Lead Approved
            </span>
            <span className="text-2xs font-mono text-slate-500 bg-slate-100 px-2.5 py-1 rounded-full">
              TARGET: SUPABASE + VERCEL
            </span>
          </div>
        </div>
      </header>

      {/* Main Core Content Area */}
      <main className="max-w-7xl mx-auto w-full px-6 py-8 flex-1 space-y-8">
        
        {/* Concept Banner / Hero */}
        <section id="hero-banner" className="bg-linear-to-r from-slate-900 via-indigo-950 to-slate-950 rounded-3xl p-6 md:p-8 text-white relative overflow-hidden shadow-lg">
          <div className="absolute inset-0 bg-radial-to-t from-transparent to-slate-950/40 pointer-events-none" />
          
          <div className="relative z-10 max-w-4xl space-y-4">
            <div className="inline-flex items-center gap-1 bg-white/10 border border-white/15 px-3 py-1 rounded-full text-xs font-mono text-indigo-200">
              <Compass size={14} /> Cognitive Linter for Student Mathematics
            </div>
            <h2 className="text-2xl md:text-4xl font-sans font-extrabold tracking-tight leading-tight">
              Tracing Student Misconceptions in Integer Operations
            </h2>
            <p className="text-sm md:text-base text-slate-300 leading-relaxed max-w-3xl font-sans">
              Alamatika Core-Trace replaces uniform grading sheets with <strong>step-by-step cognitive traces</strong>. Underpinned by deterministic algebra pipelines, a Postgres telemetry layer, and socio-pedagogical AI scaffold engines, it detects and cures mental calculation bugs in real time.
            </p>
            
            <div className="pt-4 flex flex-wrap gap-x-6 gap-y-2 text-xs font-mono text-indigo-300">
              <span className="flex items-center gap-1.5">
                <Check size={14} className="text-emerald-400" /> High Precision Rule Matrix
              </span>
              <span className="flex items-center gap-1.5">
                <Check size={14} className="text-emerald-400" /> Empathy-First Scaffold Prompts
              </span>
              <span className="flex items-center gap-1.5">
                <Check size={14} className="text-emerald-400" /> Real-time Interactive Diagrams
              </span>
            </div>
          </div>
        </section>

        {/* Tab Navigation Controls */}
        <nav id="nav-tabs" className="bg-slate-200/60 p-1 rounded-xl flex flex-wrap gap-1 max-w-full">
          {[
            { id: "overview", label: "Executive Summary", icon: <BookOpen size={14} /> },
            { id: "sandbox", label: "Manipulative Zero-Coins", icon: <Coins size={14} /> },
            { id: "simulation", label: "Core-Trace Sim Laboratory", icon: <Terminal size={14} /> },
            { id: "schema", label: "Database Schemas", icon: <Database size={14} /> },
            { id: "stack", label: "Stack Configurations", icon: <Cpu size={14} /> },
            { id: "directory", label: "Repository Tree", icon: <FolderGit2 size={14} /> },
          ].map((tab) => (
            <button
              id={`tab-main-${tab.id}`}
              key={tab.id}
              onClick={() => setActiveTab(tab.id as TabID)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-lg text-xs font-medium transition-all cursor-pointer ${
                activeTab === tab.id
                  ? "bg-white text-indigo-700 font-bold shadow-2xs"
                  : "text-slate-600 hover:text-slate-900 hover:bg-white/40"
              }`}
            >
              {tab.icon}
              <span>{tab.label}</span>
            </button>
          ))}
        </nav>

        {/* Dynamic Tab Renderers */}
        <section id="tab-visual-body" className="transition-all duration-300">
          
          {activeTab === "sandbox" && (
            <div id="sandbox-tab-view" className="space-y-6 animate-fadeIn font-sans">
              {selectedEquation && (
                <div className="bg-gradient-to-r from-amber-50 to-amber-100/50 border border-amber-200 p-4 rounded-xl flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 animate-fadeIn">
                  <div className="space-y-1">
                    <span className="text-[10px] uppercase font-mono tracking-wider font-bold text-amber-700 bg-amber-500/10 border border-amber-500/20 px-2 py-0.5 rounded-full">
                      🎯 Targeted Scaffold Intervention Mode
                    </span>
                    <h4 className="font-sans font-bold text-slate-900 text-sm mt-1">
                      Modeling Math Deficit for equation: <code className="bg-white px-2 py-0.5 rounded border border-amber-200 font-mono font-black text-amber-800">{selectedEquation.expression}</code>
                    </h4>
                    <p className="text-xs text-slate-600 leading-relaxed">
                      The core engine diagnosed misconception <strong className="font-mono text-[11px] text-indigo-750 font-bold">{selectedEquation.detectedMisconceptionCode}</strong> on this task. We've populated the workspace with representative counters to let you explore neutralizing zero-pairs.
                    </p>
                  </div>
                  <button
                    id="btn-quit-remedial"
                    onClick={() => setSelectedEquation(undefined)}
                    className="shrink-0 bg-white hover:bg-slate-100 text-slate-700 font-semibold px-3 py-1.5 rounded-xl border border-slate-200 text-xs transition-all cursor-pointer font-sans shadow-2xs"
                  >
                    Exit Remedial Practice
                  </button>
                </div>
              )}

              {!selectedEquation && (
                <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-2xs animate-fadeIn">
                  <h3 className="font-sans font-semibold text-slate-905 tracking-tight text-lg mb-1">
                    Concrete Coin Zero-Pair Workspace
                  </h3>
                  <p className="text-xs text-slate-500 font-sans">
                    Apply interactive manipulatives to model signed operations. Drag positive tokens (+1) onto negative tokens (-1) to cancel them into zero charges.
                  </p>
                </div>
              )}

              <CoinSandbox 
                initialEquation={selectedEquation} 
                onBackToDiagnostic={() => setActiveTab("simulation")} 
              />
            </div>
          )}
          
          {activeTab === "overview" && (
            <div id="overview-tab-view" className="space-y-8 animate-fadeIn">
              
              {/* Context Summary Cards */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                
                <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-2xs space-y-4">
                  <div className="w-10 h-10 rounded-xl bg-indigo-50 border border-indigo-150 flex items-center justify-center text-indigo-600">
                    <Compass size={20} />
                  </div>
                  <div>
                    <h3 className="font-sans font-bold text-slate-900 tracking-tight text-base md:text-lg">
                      The Integer Misconception Problem
                    </h3>
                    <p className="text-xs md:text-sm text-slate-600 leading-relaxed font-sans mt-2">
                      When students evaluate expressions like <code className="bg-slate-100 px-1 py-0.5 rounded text-xs font-mono text-purple-600">-5 - (-3)</code>, they rarely guess at random. Instead, their mistakes stem from coherent <strong>"buggy rules"</strong> (e.g. visualizing a subtraction symbol alongside a negative symbol as a single merged minus, arriving at <code className="bg-slate-100 px-1.5 py-0.5 rounded text-xs font-mono text-red-600">-8</code> instead of <code className="bg-slate-100 px-1.5 py-0.5 rounded text-xs font-mono text-sky-600">-2</code>).
                    </p>
                  </div>
                </div>

                <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-2xs space-y-4">
                  <div className="w-10 h-10 rounded-xl bg-emerald-50 border border-emerald-150 flex items-center justify-center text-emerald-600">
                    <Sparkles size={20} />
                  </div>
                  <div>
                    <h3 className="font-sans font-bold text-slate-900 tracking-tight text-base md:text-lg">
                      Socio-Cognitive Scaffold Remedy
                    </h3>
                    <p className="text-xs md:text-sm text-slate-600 leading-relaxed font-sans mt-2">
                      Simply highlighting an answer as "incorrect" causes learning fatigue. Alamatika Core-Trace diagnoses the specific underlying cognitive rule, triggers an interactive visualization model (like a vector thermometer or double-flip number line), and scaffolds learning using targeted prompt hooks instead of supplying numerical keys.
                    </p>
                  </div>
                </div>

              </div>

              {/* Core Misconception Catalog Details */}
              <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-2xs">
                <div className="mb-4">
                  <h3 className="font-sans font-semibold text-slate-900 text-base md:text-lg tracking-tight">
                    Primary Misconception Catalog Targets
                  </h3>
                  <p className="text-xs text-slate-500 font-sans mt-0.5">
                    Catalog of deterministic, systematic mathematical misconceptions our stack is configured to trace.
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {MISCONCONCEPTION_CATALOG.map((rule, idx) => (
                    <div id={`idx-rule-${rule.code}`} key={idx} className="p-4 rounded-xl border border-slate-100 bg-slate-50/50 flex flex-col justify-between">
                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-3xs font-mono font-bold bg-amber-50 text-amber-700 border border-amber-100 px-2 py-0.5 rounded">
                            {rule.code}
                          </span>
                          <span className="font-mono text-3xs font-bold text-slate-400">
                            PROBLEM TYPE: {rule.exampleProblem}
                          </span>
                        </div>
                        <h4 className="font-sans font-bold text-xs text-slate-800 mb-1">{rule.name}</h4>
                        <p className="text-2xs text-slate-500 leading-relaxed">{rule.underlyingBug}</p>
                      </div>

                      <div className="mt-4 pt-3 border-t border-slate-200/60 text-3xs font-mono space-y-1">
                        <div>
                          <strong className="text-slate-400">REMEDIAL PROMPT SIGNAL HOOK:</strong>
                          <p className="text-indigo-600 italic mt-0.5">"{rule.remedialSocioCognitiveHook}"</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

            </div>
          )}

          {activeTab === "stack" && (
            <div id="stack-tab-view" className="space-y-6 animate-fadeIn">
              <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-2xs">
                <h3 className="font-sans font-semibold text-slate-900 tracking-tight text-lg mb-1">
                  Full-Stack Architecture & Systems Design
                </h3>
                <p className="text-xs text-slate-500 font-sans">
                  The technologies supporting Alamatika Core-Trace are chosen to minimize cold-starts, guarantee student isolation boundaries via PostgreSQL, and ensure lightweight cost overheads.
                </p>
              </div>
              <StackSection />
            </div>
          )}

          {activeTab === "directory" && (
            <div id="directory-tab-view" className="animate-fadeIn">
              <FolderStructure />
            </div>
          )}

          {activeTab === "schema" && (
            <div id="schema-tab-view" className="animate-fadeIn">
              <DatabaseSchema />
            </div>
          )}

          {activeTab === "simulation" && (
            <div id="simulation-tab-view" className="space-y-6 animate-fadeIn">
              <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-2xs">
                <h3 className="font-sans font-semibold text-slate-900 tracking-tight text-lg mb-1">
                  Trace Pipeline Experimentation Sandbox
                </h3>
                <p className="text-xs text-slate-500 font-sans">
                  Test and observe how inputs, database parameters, and generative AI prompt matrices collaborate during active student sessions inside this interactive Lead-Architect laboratory.
                </p>
              </div>
              <TraceSimulator 
                onMisconceptionDetected={(code, failedEq) => {
                  setSelectedEquation({
                    expression: failedEq.expression,
                    a: failedEq.a,
                    b: failedEq.b,
                    detectedMisconceptionCode: code
                  });
                  setActiveTab("sandbox");
                }}
              />
            </div>
          )}

        </section>

      </main>

      {/* Footer System Blueprint Credits */}
      <footer id="app-footer" className="bg-white border-t border-slate-150 py-6 px-6 mt-12">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4 text-xs font-mono text-slate-500">
          <div>
            <span>ALAMATIKA CORE-TRACE ARCHITECTURE FRAMEWORK • V1.0</span>
          </div>
          <div className="flex gap-4">
            <span>SUPABASE SECURITY LEVEL: STRICT</span>
            <span>HOSTING ENVIRONMENT: VERCEL</span>
          </div>
        </div>
      </footer>

    </div>
  );
}
