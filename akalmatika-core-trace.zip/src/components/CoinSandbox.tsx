/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useRef, useEffect } from "react";
import { 
  Plus, 
  Minus, 
  Sparkles, 
  RotateCcw, 
  HelpCircle, 
  Coins, 
  Info,
  Trash2,
  Terminal
} from "lucide-react";

interface Coin {
  id: string;
  value: 1 | -1; // +1 (blue) or -1 (red)
  x: number; // percentage of workspace width (0 to 100)
  y: number; // percentage of workspace height (0 to 100)
  isNeutralizing: boolean;
  opacity: number;
}

interface NeutralEffect {
  id: string;
  x: number; // percentage
  y: number; // percentage
  createdAt: number;
}

export interface CoinSandboxProps {
  initialEquation?: {
    expression: string;
    a: number;
    b: number;
    correctAnswer?: number;
    detectedMisconceptionCode?: string | null;
  };
  onBackToDiagnostic?: () => void;
}

export default function CoinSandbox({ initialEquation, onBackToDiagnostic }: CoinSandboxProps = {}) {
  const [coins, setCoins] = useState<Coin[]>([]);
  const [telemetryLogs, setTelemetryLogs] = useState<{ id: string; timestamp: string; level: 'INFO' | 'WARN' | 'ERROR'; message: string }[]>([]);

  const addLog = (level: 'INFO' | 'WARN' | 'ERROR', message: string) => {
    const time = new Date().toLocaleTimeString();
    setTelemetryLogs(prev => [
      { id: Math.random().toString(), timestamp: time, level, message },
      ...prev.slice(0, 11) // Keep the last 12 log ticks
    ]);
  };

  // Monitor and set dynamic coin spawn configurations of failed equation
  useEffect(() => {
    try {
      if (initialEquation) {
        addLog('INFO', `Custom scaffolding initialized for: ${initialEquation.expression}`);
        const initialCoins: Coin[] = [];
        const posCount = initialEquation.b; // right term
        const negCount = Math.abs(initialEquation.a); // left term (usually negative)

        addLog('INFO', `Spawning ${posCount} blue (+1) nodes & ${negCount} red (-1) nodes...`);

        // Spawning positive coins on left half coordinate grid
        for (let i = 0; i < posCount; i++) {
          const ySpace = posCount > 1 ? 20 + (i * 60) / (posCount - 1) : 50;
          initialCoins.push({
            id: `init-pos-${i}-${Math.random().toString(36).substring(2, 7)}`,
            value: 1,
            x: 25 + (Math.random() * 4 - 2),
            y: ySpace,
            isNeutralizing: false,
            opacity: 1
          });
        }

        // Spawning negative coins on right half coordinate grid
        for (let i = 0; i < negCount; i++) {
          const ySpace = negCount > 1 ? 20 + (i * 60) / (negCount - 1) : 50;
          initialCoins.push({
            id: `init-neg-${i}-${Math.random().toString(36).substring(2, 7)}`,
            value: -1,
            x: 75 + (Math.random() * 4 - 2),
            y: ySpace,
            isNeutralizing: false,
            opacity: 1
          });
        }

        setCoins(initialCoins);
      } else {
        addLog('INFO', 'Loaded system-clean exploration workspace canvas.');
        // Default sandbox coins
        setCoins([
          { id: "c1", value: 1, x: 25, y: 30, isNeutralizing: false, opacity: 1 },
          { id: "c2", value: 1, x: 25, y: 60, isNeutralizing: false, opacity: 1 },
          { id: "c3", value: -1, x: 75, y: 30, isNeutralizing: false, opacity: 1 },
          { id: "c4", value: -1, x: 75, y: 60, isNeutralizing: false, opacity: 1 },
        ]);
      }
    } catch (err: any) {
      addLog('ERROR', `Scaffold Setup Exception: ${err.message || 'Unknown render trigger fault'}`);
    }
    setEffects([]);
  }, [initialEquation]);

  const [effects, setEffects] = useState<NeutralEffect[]>([]);
  const [activeDragId, setActiveDragId] = useState<string | null>(null);
  const workspaceRef = useRef<HTMLDivElement>(null);
  const dragOffsetRef = useRef({ x: 0, y: 0 });

  // Calculate Net Value of current active non-neutralized coins
  const netValue = coins
    .filter(c => !c.isNeutralizing)
    .reduce((sum, c) => sum + c.value, 0);

  // Counters
  const positiveCount = coins.filter(c => !c.isNeutralizing && c.value === 1).length;
  const negativeCount = coins.filter(c => !c.isNeutralizing && c.value === -1).length;

  // Add random coins securely
  const spawnCoin = (value: 1 | -1) => {
    const id = `coin-${Math.random().toString(36).substring(2, 11)}`;
    const newCoin: Coin = {
      id,
      value,
      x: value === 1 ? 15 + Math.random() * 20 : 65 + Math.random() * 20,
      y: 20 + Math.random() * 55,
      isNeutralizing: false,
      opacity: 1
    };
    setCoins(prev => [...prev, newCoin]);
  };

  // Reset sandbox completely
  const handleReset = () => {
    if (initialEquation) {
      const initialCoins: Coin[] = [];
      const posCount = initialEquation.b;
      const negCount = Math.abs(initialEquation.a);

      for (let i = 0; i < posCount; i++) {
        const ySpace = posCount > 1 ? 20 + (i * 60) / (posCount - 1) : 50;
        initialCoins.push({
          id: `init-pos-${i}-${Math.random().toString(36).substring(2, 7)}`,
          value: 1,
          x: 25 + (Math.random() * 4 - 2),
          y: ySpace,
          isNeutralizing: false,
          opacity: 1
        });
      }

      for (let i = 0; i < negCount; i++) {
        const ySpace = negCount > 1 ? 20 + (i * 60) / (negCount - 1) : 50;
        initialCoins.push({
          id: `init-neg-${i}-${Math.random().toString(36).substring(2, 7)}`,
          value: -1,
          x: 75 + (Math.random() * 4 - 2),
          y: ySpace,
          isNeutralizing: false,
          opacity: 1
        });
      }
      setCoins(initialCoins);
    } else {
      setCoins([
        { id: "c1", value: 1, x: 25, y: 30, isNeutralizing: false, opacity: 1 },
        { id: "c2", value: 1, x: 25, y: 60, isNeutralizing: false, opacity: 1 },
        { id: "c3", value: -1, x: 75, y: 30, isNeutralizing: false, opacity: 1 },
        { id: "c4", value: -1, x: 75, y: 60, isNeutralizing: false, opacity: 1 },
      ]);
    }
    setEffects([]);
  };

  // Clear all coins
  const handleClear = () => {
    setCoins([]);
    setEffects([]);
  };

  // Drag Handlers
  const handleStartDrag = (id: string, clientX: number, clientY: number) => {
    const coin = coins.find(c => c.id === id);
    if (!coin || coin.isNeutralizing || !workspaceRef.current) return;

    const rect = workspaceRef.current.getBoundingClientRect();
    const currentXpx = (coin.x / 100) * rect.width;
    const currentYpx = (coin.y / 100) * rect.height;

    // Relative offset of the touch click inside the workspace
    dragOffsetRef.current = {
      x: clientX - rect.left - currentXpx,
      y: clientY - rect.top - currentYpx
    };
    setActiveDragId(id);
  };

  const handleDragMove = (clientX: number, clientY: number) => {
    if (!activeDragId || !workspaceRef.current) return;

    try {
      const rect = workspaceRef.current.getBoundingClientRect();
      if (rect.width <= 0 || rect.height <= 0) {
        throw new Error("Invalid responsive canvas footprint dimension (0px width or height detected)");
      }

      const cursorX = clientX - rect.left - dragOffsetRef.current.x;
      const cursorY = clientY - rect.top - dragOffsetRef.current.y;

      if (isNaN(cursorX) || isNaN(cursorY)) {
        throw new Error("Pointer interaction coordinate computation resolved to NaN.");
      }

      // Convert back lock-in coordinates to sandbox percentages
      let newX = (cursorX / rect.width) * 100;
      let newY = (cursorY / rect.height) * 100;

      // Enforce canvas margins boundary safety
      newX = Math.max(4, Math.min(96, newX));
      newY = Math.max(5, Math.min(95, newY));

      // Update coordinates immediately
      setCoins(prev =>
        prev.map(c => (c.id === activeDragId ? { ...c, x: newX, y: newY } : c))
      );
    } catch (err: any) {
      addLog('ERROR', `Drag Physics Crash Caught: ${err.message || 'Coordinate exception'}`);
    }
  };

  const handleEndDrag = () => {
    if (!activeDragId) return;
    addLog('INFO', `Ended pointer drag session for node ID: ${activeDragId.slice(0, 10)}`);
    setActiveDragId(null);
  };

  // Monitor collision events in coordinates
  useEffect(() => {
    if (activeDragId === null) return;

    try {
      const draggingCoin = coins.find(c => c.id === activeDragId);
      if (!draggingCoin || draggingCoin.isNeutralizing) return;

      // Find overlapping opposite coin
      const collisionOverlapTarget = coins.find(other => {
        if (other.id === draggingCoin.id || other.isNeutralizing) return false;
        
        // Values must be opposite signs to collapse each other (+1 and -1)
        if (other.value === draggingCoin.value) return false;

        // Distance estimation using Euclidean bounding elements
        const dx = other.x - draggingCoin.x;
        const dy = other.y - draggingCoin.y;
        
        // Let's assume a coin radius takes up ~5% width/height coordinates.
        // A distance of less than 7 units indicates overlapping collision
        const distance = Math.sqrt(dx * dx + dy * dy);
        if (isNaN(distance)) {
          throw new Error("Euclidean distance computation yielded NaN value.");
        }
        return distance < 8.2;
      });

      if (collisionOverlapTarget) {
        const effectX = (draggingCoin.x + collisionOverlapTarget.x) / 2;
        const effectY = (draggingCoin.y + collisionOverlapTarget.y) / 2;

        addLog('INFO', `Collision Detected! Neutralizing opposite charges: ${draggingCoin.value} and ${collisionOverlapTarget.value}`);

        // Trigger neutralization transitions on both coins immediately
        const id1 = draggingCoin.id;
        const id2 = collisionOverlapTarget.id;

        setActiveDragId(null); // break drag focus

        setCoins(prev =>
          prev.map(c =>
            c.id === id1 || c.id === id2
              ? { ...c, isNeutralizing: true }
              : c
          )
        );

        // Create a nice localized explosion canvas indicator
        const newEffectId = `eff-${Date.now()}-${Math.random()}`;
        setEffects(prev => [...prev, { id: newEffectId, x: effectX, y: effectY, createdAt: Date.now() }]);

        // Remove after animations fade out completely
        setTimeout(() => {
          setCoins(prev => prev.filter(c => c.id !== id1 && c.id !== id2));
        }, 700);
      }
    } catch (err: any) {
      addLog('ERROR', `Collision Algorithm Slip: ${err.message || 'Animation distance error'}`);
    }
  }, [coins, activeDragId]);

  // Clean obsolete effects
  useEffect(() => {
    const timer = setInterval(() => {
      const now = Date.now();
      setEffects(prev => prev.filter(e => now - e.createdAt < 1200));
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div id="coin-sandbox" className="grid grid-cols-1 lg:grid-cols-12 gap-6 bg-white p-6 rounded-2xl border border-slate-100 shadow-sm">
      
      {/* Sandbox control parameters (left col) */}
      <div className="lg:col-span-4 flex flex-col justify-between space-y-6">
        <div className="space-y-4">
          <div>
            <div className="flex items-center justify-between">
              <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-3xs font-mono bg-indigo-50 text-indigo-700 border border-indigo-150 tracking-wide font-semibold uppercase">
                <Coins size={12} strokeWidth={2.5} /> {initialEquation ? "Active Remedial Practice" : "Concrete Manipulatives"}
              </div>
              {onBackToDiagnostic && (
                <button
                  id="btn-back-to-diagnostics"
                  onClick={onBackToDiagnostic}
                  className="font-mono text-3xs font-bold text-indigo-600 hover:text-indigo-800 hover:underline flex items-center gap-0.5 transition-all cursor-pointer"
                >
                  &larr; Back to Lab
                </button>
              )}
            </div>
            <h3 className="font-sans font-bold text-slate-900 text-lg mt-2 tracking-tight">
              {initialEquation ? `Modeling: ${initialEquation.expression}` : "Zero-Pair Coin Sandbox"}
            </h3>
            <p className="text-xs text-slate-500 font-sans mt-1 leading-relaxed">
              {initialEquation ? (
                <span>
                  Let's model the equation <strong className="text-indigo-650 font-mono font-bold select-all">{initialEquation.expression}</strong> together! We spawned <strong className="text-rose-600 font-bold">{Math.abs(initialEquation.a)} negative (red)</strong> coins and <strong className="text-sky-600 font-bold">{initialEquation.b} positive (blue)</strong> coins. Drag opposite charges together to neutralize!
                </span>
              ) : (
                <span>
                  Drag positive (<strong className="text-sky-600">Blue +1</strong>) coins over negative (<strong className="text-rose-600">Red -1</strong>) coins to visualize algebraic neutralization.
                </span>
              )}
            </p>
          </div>

          {/* Quick Spawn Controls */}
          <div className="space-y-2">
            <span className="text-2xs font-mono font-bold text-slate-400 block uppercase">Spawn Manipulatives</span>
            <div className="grid grid-cols-2 gap-2">
              <button
                id="btn-spawn-positive"
                onClick={() => spawnCoin(1)}
                className="flex items-center justify-center gap-1.5 bg-sky-50 border border-sky-200 hover:bg-sky-100/80 active:translate-y-0.5 text-sky-700 font-semibold px-3 py-2 rounded-xl text-xs transition-all cursor-pointer font-sans"
              >
                <Plus size={14} strokeWidth={2.5} />
                <span>Positive (+1)</span>
              </button>
              <button
                id="btn-spawn-negative"
                onClick={() => spawnCoin(-1)}
                className="flex items-center justify-center gap-1.5 bg-rose-50 border border-rose-200 hover:bg-rose-100/90 active:translate-y-0.5 text-rose-700 font-semibold px-3 py-2 rounded-xl text-xs transition-all cursor-pointer font-sans"
              >
                <Minus size={14} strokeWidth={2.5} />
                <span>Negative (-1)</span>
              </button>
            </div>
          </div>

          {/* Real-time Math Ledger Card */}
          <div className="bg-slate-50 border border-slate-150 p-4 rounded-xl space-y-3">
            <span className="text-3xs font-mono font-bold text-slate-405 block uppercase tracking-wider">WORKSPACE MATH LEDGER</span>
            
            <div className="grid grid-cols-3 gap-2 text-center text-xs font-mono">
              <div className="bg-white p-2 rounded-lg border border-slate-100">
                <span className="text-sky-600 font-bold text-base block">{positiveCount}</span>
                <span className="text-3xs text-slate-400">POS COINS</span>
              </div>
              <div className="bg-white p-2 rounded-lg border border-slate-100">
                <span className="text-rose-600 font-bold text-base block">{negativeCount}</span>
                <span className="text-3xs text-slate-400">NEG COINS</span>
              </div>
              <div className="bg-white p-2 rounded-lg border border-slate-100">
                <span className={`font-extrabold text-base block ${netValue > 0 ? "text-sky-600" : netValue < 0 ? "text-rose-600" : "text-slate-500"}`}>
                  {netValue > 0 ? `+${netValue}` : netValue}
                </span>
                <span className="text-3xs text-slate-400">NET VALUE</span>
              </div>
            </div>

            {/* Algebraic Representation Expression */}
            <div className="bg-white p-3 rounded-xl border border-slate-100 text-center select-all">
              <span className="text-3xs font-mono text-slate-400 block mb-0.5">ALGEBRAIC REPRESENTATION</span>
              <span className="font-mono text-sm font-extrabold text-slate-800">
                {positiveCount === 0 && negativeCount === 0 ? "0" : (
                  <>
                    {Array(positiveCount).fill("(+1)").join(" + ") || ""}
                    {positiveCount > 0 && negativeCount > 0 ? " + " : ""}
                    {Array(negativeCount).fill("(-1)").join(" + ") || ""}
                    <span className="text-slate-400 mx-1">=</span>
                    <span className={`${netValue > 0 ? "text-sky-600" : netValue < 0 ? "text-rose-600" : "text-slate-700"}`}>
                      {netValue}
                    </span>
                  </>
                )}
              </span>
            </div>
          </div>

          {/* Telemetry Tracking Terminal Logs to monitor drag performance and catch NaN crashes */}
          <div className="bg-slate-950 border border-slate-850 p-3.5 rounded-xl space-y-2.5 font-mono text-[10px] text-slate-300">
            <div className="flex items-center justify-between pb-1.5 border-b border-slate-800 select-none">
              <span className="flex items-center gap-1.5 font-bold text-slate-400">
                <Terminal size={12} className="text-indigo-400 animate-pulse" /> Sandbox Diagnostics
              </span>
              <span className="text-[8px] bg-slate-900 border border-slate-800 text-slate-500 px-1 py-0.5 rounded">
                TELEMETRY
              </span>
            </div>
            <div className="max-h-[90px] overflow-y-auto space-y-1 scrollbar-thin pr-1 text-[9.5px]">
              {telemetryLogs.length === 0 ? (
                <div className="text-slate-600 italic">// Interactive session trace empty. Drag coins to log metrics...</div>
              ) : (
                telemetryLogs.map((log) => (
                  <div key={log.id} className="flex gap-1.5 leading-normal">
                    <span className="text-slate-500 font-normal">[{log.timestamp}]</span>
                    <span className={`font-bold shrink-0 text-[9px] px-1 rounded uppercase ${
                      log.level === 'ERROR' 
                        ? 'bg-rose-950 border border-rose-900/40 text-rose-400' 
                        : log.level === 'WARN' 
                          ? 'bg-amber-950 border border-amber-900/40 text-amber-400' 
                          : 'bg-emerald-990 border border-emerald-900/40 text-emerald-400'
                    }`}>
                      {log.level}
                    </span>
                    <span className="text-slate-300 font-sans tracking-wide">{log.message}</span>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>

        {/* Workspace Utility Control Row */}
        <div className="flex gap-2">
          <button
            id="btn-reset-sandbox"
            onClick={handleReset}
            className="flex-1 border border-slate-200 hover:bg-slate-50 text-slate-650 px-3 py-2 rounded-xl text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer font-sans"
          >
            <RotateCcw size={12} />
            <span>Restore Defaults</span>
          </button>
          <button
            id="btn-clear-sandbox"
            onClick={handleClear}
            className="border border-slate-200 text-slate-500 hover:text-rose-600 hover:bg-rose-50 px-3 py-2 rounded-xl text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
            title="Delete All Coins"
          >
            <Trash2 size={12} />
          </button>
        </div>
      </div>

      {/* Interactive Drag Canvas (right col) */}
      <div className="lg:col-span-8 flex flex-col justify-between">
        
        {/* Workspace Canvas Board */}
        <div 
          id="coincidence-canvas-board"
          ref={workspaceRef}
          onMouseMove={(e) => handleDragMove(e.clientX, e.clientY)}
          onMouseUp={handleEndDrag}
          onMouseLeave={handleEndDrag}
          onTouchMove={(e) => {
            if (e.touches.length > 0) {
              handleDragMove(e.touches[0].clientX, e.touches[0].clientY);
            }
          }}
          onTouchEnd={handleEndDrag}
          className="relative w-full h-[380px] bg-slate-900 border border-slate-950 rounded-2xl overflow-hidden shadow-inner select-none cursor-grab active:cursor-grabbing"
        >
          {/* grid overlay decoration */}
          <div className="absolute inset-0 bg-[linear-gradient(to_right,#1e293b_1px,transparent_1px),linear-gradient(to_bottom,#1e293b_1px,transparent_1px)] bg-[size:24px_24px] opacity-25" />
          
          {/* Zero Neutralizer Line boundary reference */}
          <div className="absolute inset-y-0 left-1/2 w-px border-l-2 border-dashed border-slate-800/80 pointer-events-none flex items-center justify-center">
            <span className="transform -rotate-90 text-[10px] uppercase font-mono tracking-wider font-bold text-slate-600 whitespace-nowrap select-none bg-slate-900 border border-slate-850 px-2 py-0.5 rounded -translate-x-1/2">
              neutral charge divider
            </span>
          </div>

          {/* Render Active Draggable Coins inside board */}
          {coins.map((coin) => {
            const isDragging = activeDragId === coin.id;
            const isPositive = coin.value === 1;

            return (
              <div
                id={`draggable-coin-${coin.id}`}
                key={coin.id}
                onMouseDown={(e) => {
                  e.preventDefault();
                  handleStartDrag(coin.id, e.clientX, e.clientY);
                }}
                onTouchStart={(e) => {
                  if (e.touches.length > 0) {
                    handleStartDrag(coin.id, e.touches[0].clientX, e.touches[0].clientY);
                  }
                }}
                style={{
                  left: `${coin.x}%`,
                  top: `${coin.y}%`,
                  transform: `translate(-50%, -50%) scale(${coin.isNeutralizing ? 1.3 : isDragging ? 1.12 : 1})`,
                  opacity: coin.isNeutralizing ? 0 : 1,
                  transition: coin.isNeutralizing 
                    ? "opacity 600ms cubic-bezier(0.16, 1, 0.3, 1), transform 500ms cubic-bezier(0.16, 1, 0.3, 1)" 
                    : isDragging 
                      ? "none" 
                      : "transform 150ms ease-out",
                  zIndex: isDragging ? 40 : 10
                }}
                className={`absolute w-12 h-12 rounded-full flex items-center justify-center font-mono font-black text-sm select-none border-2 shadow-md cursor-grab active:cursor-grabbing ${
                  isPositive
                    ? "bg-sky-500 border-sky-300 text-sky-950 shadow-sky-900/30 text-shadow-sky"
                    : "bg-rose-500 border-rose-300 text-rose-950 shadow-rose-900/30 text-shadow-rose"
                }`}
              >
                {/* Visual design patterns replicating standard teacher counters */}
                <div className="absolute inset-1 border border-white/20 rounded-full flex items-center justify-center">
                  <span>{isPositive ? "+1" : "-1"}</span>
                </div>
              </div>
            );
          })}

          {/* Render Neutralized Explosion Particles */}
          {effects.map((effect) => (
            <div
              key={effect.id}
              style={{
                left: `${effect.x}%`,
                top: `${effect.y}%`,
                transform: "translate(-50%, -50%)",
              }}
              className="absolute pointer-events-none z-30 flex flex-col items-center justify-center"
            >
              <div className="w-16 h-16 rounded-full border-2 border-indigo-500/80 animate-ping absolute" />
              <div className="w-8 h-8 rounded-full border border-white/60 animate-pulse absolute" />
              <span className="font-mono text-3xs font-extrabold text-white bg-indigo-600 border border-indigo-400 rounded-md px-1.5 py-0.5 shadow-md flex items-center gap-1 scale-90 animate-fadeOut shrink-0 whitespace-nowrap">
                <Sparkles size={10} className="animate-spin" /> ZERO-PAIR (+1 + -1 = 0)
              </span>
            </div>
          ))}

          {/* Core instruction help footer on canvas */}
          {coins.length === 0 && (
            <div className="absolute inset-0 flex flex-col items-center justify-center text-slate-500 p-8 text-center pointer-events-none">
              <Coins size={32} className="mb-2 text-slate-700 animate-bounce" />
              <p className="text-xs font-semibold text-slate-400">Zero-Pair Playground Clear.</p>
              <p className="text-3xs text-slate-600 mt-1">Spawn new (+1) or (-1) tokens using the controllers on the left.</p>
            </div>
          )}

        </div>

        {/* Small tips context */}
        <div className="mt-4 bg-slate-50 border border-slate-150 p-4 rounded-xl flex items-start gap-2.5 text-slate-650 text-xs">
          <Info size={14} className="text-slate-400 shrink-0 mt-0.5" />
          <p className="leading-relaxed">
            <strong>Cognitive Hint:</strong> Adding two numbers of opposite signs can be solved by visualizing pairs cancelling each other out. After zero-pairs have neutralized, the remaining coin count represents your final net calculation balance!
          </p>
        </div>

      </div>

    </div>
  );
}
