/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Equation {
  expression: string;
  a: number;
  b: number;
  correctAnswer: number;
}

export interface MisconceptionRule {
  code: string;
  name: string;
  description: string;
  pattern: string;
  remedialScaffold: string;
  // Predicts the answers a student with this specific misconception would give for the active cluster.
  predictAnswers: (cluster: Equation[]) => number[];
}

// The exact math cluster defined for diagnosis
export const DIAGNOSTIC_CLUSTER: Equation[] = [
  { expression: "-2 + 3", a: -2, b: 3, correctAnswer: 1 },
  { expression: "-3 + 5", a: -3, b: 5, correctAnswer: 2 },
  { expression: "-1 + 4", a: -1, b: 4, correctAnswer: 3 }
];

export const ENGINE_RULES: MisconceptionRule[] = [
  {
    code: "MC-ADD-SIGN-CONF",
    name: "Absolute Sum Rule Confusion",
    description: "Student treats '-a + b' by adding the absolute values together and assigning a negative sign, i.e., -(a + b).",
    pattern: "-a + b => -(abs(a) + abs(b))",
    remedialScaffold: "Help the student realize addition is dynamic tracking. If you start with $2 debt and earn $3, you do not sink deeper to $5 debt! Feel the positive movement on a number line.",
    predictAnswers: (cluster) => {
      // Maps e.g. -2 + 3 to -(2 + 3) = -5
      return cluster.map(eq => -(Math.abs(eq.a) + Math.abs(eq.b)));
    }
  },
  {
    code: "MC-SIGN-FIRST-NUM",
    name: "Sign Follows First Number Error",
    description: "Student subtracts the smaller absolute value from the larger, but forces the sign of the result to match the sign of the first term regardless of relative values.",
    pattern: "-a + b => -(|b| - |a|) since the first term is negative.",
    remedialScaffold: "Ask the student: 'Which amount is larger: your debt or your cash?' Since your cash ($3) is larger than your debt ($2), the final result has to be in the positive balance field.",
    predictAnswers: (cluster) => {
      // For each equation in the cluster, since the first number is negative, they subtract but make it negative
      return cluster.map(eq => -Math.abs(Math.abs(eq.b) - Math.abs(eq.a)));
    }
  },
  {
    code: "MC-ADD-ABS-SUM",
    name: "Absolute Addition (Ignore Negatives)",
    description: "Student ignores negative signs completely, treating all additions as absolute positive sum calculations.",
    pattern: "-a + b => abs(a) + abs(b)",
    remedialScaffold: "Direct the student's attention to signs: 'Signs aren't decorations; they are active operators.' Help them feel the physical difference between holding money and being in debt.",
    predictAnswers: (cluster) => {
      return cluster.map(eq => Math.abs(eq.a) + Math.abs(eq.b));
    }
  },
  {
    code: "MC-SUBTRACT-INVERT",
    name: "Subtracted Absolute Order Inversion",
    description: "Student treats addition of differing signs as absolute subtraction but reverses normal bounds, calculating second minus first directly as positive.",
    pattern: "-a + b => abs(b) - abs(a)",
    remedialScaffold: "Point to standard subtraction pathways. Ensure the balance direction matches correct sign weighting.",
    predictAnswers: (cluster) => {
      // e.g. 3 - 2 = 1. Wait, this actually yields the correct answers! Double check.
      // -2 + 3 => 3 - 2 = 1
      // For this specific addition cluster, this is mathematically identical to correct addition.
      // Thus, we will skip predicting correct answers as misconceptions to avoid false positives!
      return [];
    }
  }
];
